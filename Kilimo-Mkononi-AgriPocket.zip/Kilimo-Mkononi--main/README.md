# Kilimo Mkononi — Powered by AgriPocket

Prototype ya kidijitali ya kusaidia uratibu wa masoko ya mazao, pembejeo, huduma za kilimo, mabaki ya kilimo na fursa za nishati safi.

## Features in this demo
- Crop marketplace and input-store demo
- Agricultural residue / waste-to-energy connection request form
- Solar cold-storage request form
- Logistics coordination request form
- AI advisory, crop scanner, QR traceability and finance demo screens

## Important limitations
This is a front-end prototype. New requests are stored in the browser's local storage on the current device only; they are not sent to a server or service provider. Sample listings and scanner responses are demo content, not verified live services or professional diagnosis. No loan is approved by this prototype.

## Deployment
GitHub Pages can host `index.html` as a static site. The Python file `ai_service.py` does not run on GitHub Pages; it requires a separate backend deployment before the website can call it.

## Security
Never commit `.env` or API keys. Configure secrets only in a secure backend environment.
